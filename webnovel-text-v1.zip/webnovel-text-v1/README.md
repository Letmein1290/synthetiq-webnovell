# WebNovel Text (Experimental)

Synthetiq Player text-module first pass scoped to **I Got a Gallery in the Wild**.

## Important status

This is an experimental adapter scaffold, not a verified working module. The public catalogue is visible in ordinary web access, but this environment cannot execute requests through Synthetiq Player's `fetchv2` runtime. Search is deliberately scoped to the requested title; chapter and text parsing may need adjustments after import/runtime testing.

It does not log in, use cookies, bypass coin/paywall restrictions, defeat bot checks, or bundle copyrighted chapter text. It only requests public pages and parses content that the source returns.

## Files

- `webnovel-text-v1.json` — Synthetiq Player v3 text manifest
- `index.js` — text handlers: `searchResults`, `extractDetails`, `extractChapters`, `extractText`

## First test

Import the ZIP in Synthetiq Player's module import flow. Search for `I Got a Gallery in the Wild`, open the result, then try the chapter list and a chapter. If a step fails, report the exact step/error; do not treat static checks as proof of runtime compatibility.
