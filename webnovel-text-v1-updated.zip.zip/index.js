/*
 * Experimental Synthetiq Player text adapter for WebNovel.
 * This is a conservative first pass: it uses only public page URLs and does
 * not sign in, access cookies, bypass paywalls, or defeat site protections.
 * Real Player runtime testing is still required.
 */
(function () {
  'use strict';
  var BASE = 'https://www.webnovel.com';
  var BOOK_ID = '36934014908927805';
  var BOOK_URL = BASE + '/book/' + BOOK_ID + '/catalog';
  var UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile';

  function absUrl(href) {
    if (!href) return '';
    if (/^https?:\/\//i.test(href)) return href;
    if (href.charAt(0) === '/') return BASE + href;
    return BASE + '/' + href;
  }
  function decodeEntities(s) {
    return String(s || '')
      .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(Number(n)); });
  }
  function stripTags(s) {
    return decodeEntities(String(s || '').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
  }
  function attr(tag, name) {
    var re = new RegExp('\\b' + name + '\\s*=\\s*["\\\']([^"\\\']*)["\\\']', 'i');
    var m = re.exec(tag);
    return m ? decodeEntities(m[1]) : '';
  }
  async function getText(url) {
if (typeof fetchv2 !== 'function') {
throw new Error('This Player runtime does not expose fetchv2.');
}

var res = await fetchv2(
url,
{ 'Referer': BASE + '/' },
'GET',
null
);

if (!res || (res.status && res.status >= 400)) {
throw new Error(
'WebNovel request failed' +
(res && res.status ? ' (' + res.status + ')' : '') + '.'
);
}

var body = '';

if (typeof res.json === 'function') {
try {
var data = await res.json();
body = JSON.stringify(data);
} catch (_) {}
}

if (!body && typeof res.text === 'function') {
try {
body = await res.text();
} catch (_) {}
}

if (!body && typeof res.body === 'string') {
body = res.body;
}

if (!body) {
throw new Error('WebNovel returned no readable response.');
}

if (/captcha|verify you are human|access denied/i.test(body.slice(0, 50000))) {
throw new Error('WebNovel returned a protection page; this module will not bypass it.');
}

return body;
}

  function bookItem() {
    return { id: BOOK_ID, title: 'I Got a Gallery in the Wild', href: BOOK_URL, url: BOOK_URL,
      description: 'Open the WebNovel catalogue for the available chapters.', image: '' };
  }
  function findChapterLinks(html) {
    var out = [], seen = Object.create(null), re = /<a\b[^>]*href\s*=\s*(["'])(.*?)\1[^>]*>([\s\S]*?)<\/a>/gi, m;
    while ((m = re.exec(html))) {
      var href = absUrl(decodeEntities(m[2]));
      var title = stripTags(m[3]);
      if (!/webnovel\.com\/book\//i.test(href) || !/chapter/i.test(href + ' ' + title)) continue;
      if (!title || seen[href]) continue;
      seen[href] = true;
      var n = /chapter\s*(\d+)/i.exec(title) || /chapter[-_/](\d+)/i.exec(href);
      out.push({ id: href, href: href, url: href, title: title, number: n ? Number(n[1]) : out.length + 1 });
    }
    return out;
  }
  globalThis.searchResults = async function (query, page) {
    var q = String(query || '').toLowerCase();
    var title = 'i got a gallery in the wild';
    if (!q || title.indexOf(q) !== -1 || q.indexOf('gallery') !== -1 || q.indexOf('wild') !== -1) return [bookItem()];
    // This first version is intentionally scoped to the requested novel.
    return [];
  };
  globalThis.extractDetails = async function (urlOrId) {
    var url = String(urlOrId || '');
    if (url.indexOf('http') !== 0) url = BOOK_URL;
    var html = await getText(url);
    var titleMatch = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
    var title = titleMatch ? stripTags(titleMatch[1]).replace(/\s*[-|].*$/, '') : 'I Got a Gallery in the Wild';
    var descMatch = /(?:book-intro|bookDesc|description)[^>]*>([\s\S]{0,3000}?)<\//i.exec(html);
    return { id: BOOK_ID, href: BOOK_URL, title: title || 'I Got a Gallery in the Wild', description: descMatch ? stripTags(descMatch[1]) : 'WebNovel catalogue', image: '' };
  };
  globalThis.extractChapters = async function (seriesId) {
    var url = String(seriesId || BOOK_URL);
    if (url.indexOf('http') !== 0) url = BOOK_URL;
    var html = await getText(url);
    var chapters = findChapterLinks(html);
    if (!chapters.length) throw new Error('No chapter links could be parsed from WebNovel HTML in this runtime.');
    return chapters;
  };
 
globalThis.extractText = async function (sectionId) {
    var url = String(sectionId || '');

    if (url.indexOf('http') !== 0) {
        throw new Error('A chapter URL is required.');
    }

    var response = await getText(url);
    var data = response;

    if (typeof response === 'string') {
        try {
            data = JSON.parse(response);
        } catch (e) {
            throw new Error(
                'WebNovel chapter response was not valid JSON.'
            );
        }
    }

    var chapterInfo =
        data &&
        data.data &&
        data.data.chapterInfo;

    var contents =
        chapterInfo &&
        chapterInfo.contents;

    if (!Array.isArray(contents)) {
        throw new Error(
            'Could not find data.chapterInfo.contents in the response.'
        );
    }

    var paragraphs = contents
        .map(function (paragraph) {
            return paragraph &&
                typeof paragraph.content === 'string'
                ? paragraph.content.trim()
                : '';
        })
        .filter(function (paragraph) {
            return paragraph.length > 0;
        });

    var content = paragraphs.join('\n\n');

    if (content.length < 80) {
        throw new Error(
            'WebNovel returned no readable chapter text.'
        );
    }

    return content;
};
})();